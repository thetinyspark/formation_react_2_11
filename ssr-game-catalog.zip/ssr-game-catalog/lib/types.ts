export type Product = {
  id: number;
  name: string;
  price: number;
  description: string;
  img: string;
  platform: string;
};
